// Efeitos sonoros para o jogo
// Este arquivo será carregado como um módulo JavaScript

// Função para criar efeitos sonoros básicos usando Web Audio API
function createSoundEffects() {
    // Verificar se o navegador suporta Web Audio API
    if (!window.AudioContext && !window.webkitAudioContext) {
        console.error('Web Audio API não é suportada neste navegador');
        return null;
    }
    
    // Criar contexto de áudio
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const audioContext = new AudioContext();
    
    // Função para criar um som de acerto (hit)
    function createHitSound() {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(880, audioContext.currentTime); // Nota A5
        oscillator.frequency.exponentialRampToValueAtTime(440, audioContext.currentTime + 0.1); // Descer para A4
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.1);
    }
    
    // Função para criar um som de erro (miss)
    function createMissSound() {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(220, audioContext.currentTime); // Nota A3
        oscillator.frequency.exponentialRampToValueAtTime(110, audioContext.currentTime + 0.2); // Descer para A2
        
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.2);
    }
    
    // Função para criar um som de menu (hover)
    function createHoverSound() {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // Nota A4
        oscillator.frequency.exponentialRampToValueAtTime(660, audioContext.currentTime + 0.05); // Subir para E5
        
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05);
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.05);
    }
    
    // Função para criar um som de seleção (select)
    function createSelectSound() {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // Nota A4
        oscillator.frequency.exponentialRampToValueAtTime(880, audioContext.currentTime + 0.1); // Subir para A5
        
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.1);
    }
    
    // Retornar funções para reproduzir os sons
    return {
        hit: createHitSound,
        miss: createMissSound,
        hover: createHoverSound,
        select: createSelectSound,
        context: audioContext
    };
}

// Função para criar uma música de demonstração usando osciladores
function createDemoMusic(audioContext, duration = 30) {
    // Criar nós de áudio
    const oscillator1 = audioContext.createOscillator();
    const oscillator2 = audioContext.createOscillator();
    const oscillator3 = audioContext.createOscillator();
    const gainNode1 = audioContext.createGain();
    const gainNode2 = audioContext.createGain();
    const gainNode3 = audioContext.createGain();
    
    // Configurar osciladores
    oscillator1.type = 'square';
    oscillator2.type = 'sawtooth';
    oscillator3.type = 'sine';
    
    // Configurar ganho inicial
    gainNode1.gain.value = 0.1;
    gainNode2.gain.value = 0.05;
    gainNode3.gain.value = 0.15;
    
    // Conectar nós
    oscillator1.connect(gainNode1);
    oscillator2.connect(gainNode2);
    oscillator3.connect(gainNode3);
    gainNode1.connect(audioContext.destination);
    gainNode2.connect(audioContext.destination);
    gainNode3.connect(audioContext.destination);
    
    // Definir sequência de notas (frequências em Hz)
    const notes = [
        261.63, // C4
        293.66, // D4
        329.63, // E4
        349.23, // F4
        392.00, // G4
        440.00, // A4
        493.88, // B4
        523.25  // C5
    ];
    
    // Duração de cada nota em segundos
    const noteDuration = 0.5;
    
    // Programar mudanças de frequência para criar uma melodia
    let time = audioContext.currentTime;
    
    for (let i = 0; i < duration / noteDuration; i++) {
        // Escolher notas para cada oscilador
        const note1 = notes[i % notes.length];
        const note2 = notes[(i + 2) % notes.length];
        const note3 = notes[(i + 4) % notes.length];
        
        // Programar mudanças de frequência
        oscillator1.frequency.setValueAtTime(note1, time);
        oscillator2.frequency.setValueAtTime(note2, time);
        oscillator3.frequency.setValueAtTime(note3, time);
        
        // Adicionar um pequeno fade in/out para suavizar transições
        gainNode1.gain.setValueAtTime(0.05, time);
        gainNode1.gain.linearRampToValueAtTime(0.1, time + noteDuration * 0.1);
        gainNode1.gain.linearRampToValueAtTime(0.05, time + noteDuration * 0.9);
        
        gainNode2.gain.setValueAtTime(0.025, time);
        gainNode2.gain.linearRampToValueAtTime(0.05, time + noteDuration * 0.1);
        gainNode2.gain.linearRampToValueAtTime(0.025, time + noteDuration * 0.9);
        
        gainNode3.gain.setValueAtTime(0.075, time);
        gainNode3.gain.linearRampToValueAtTime(0.15, time + noteDuration * 0.1);
        gainNode3.gain.linearRampToValueAtTime(0.075, time + noteDuration * 0.9);
        
        // Avançar no tempo
        time += noteDuration;
    }
    
    // Iniciar osciladores
    oscillator1.start();
    oscillator2.start();
    oscillator3.start();
    
    // Parar osciladores após a duração especificada
    oscillator1.stop(audioContext.currentTime + duration);
    oscillator2.stop(audioContext.currentTime + duration);
    oscillator3.stop(audioContext.currentTime + duration);
    
    // Retornar objeto com métodos para controlar a música
    return {
        stop: function() {
            oscillator1.stop();
            oscillator2.stop();
            oscillator3.stop();
        }
    };
}

// Exportar funções
window.AudioEffects = {
    createSoundEffects,
    createDemoMusic
};
