class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
    }

    init(data) {
        this.songIndex = data.songIndex;
        this.songData = data.songData;
    }

    preload() {
        // Carregando recursos para o jogo
        this.load.image('game_bg', 'images/game_bg.jpg');
        this.load.image('note', 'images/note.png');
        this.load.image('highway', 'images/highway.png');
        this.load.image('button', 'images/button.png');
        
        // Efeitos sonoros
        this.load.audio('hit_sound', 'audio/hit.mp3');
        this.load.audio('miss_sound', 'audio/miss.mp3');
    }

    create() {
        // Background
        this.background = this.add.tileSprite(0, 0, 800, 600, 'game_bg')
            .setOrigin(0)
            .setScrollFactor(0);
            
        // Sons de efeito
        this.hitSound = this.sound.add('hit_sound', { volume: 0.5 });
        this.missSound = this.sound.add('miss_sound', { volume: 0.5 });
        
        // Informações da música
        this.add.text(400, 30, `${this.songData.title} - ${this.songData.artist}`, { 
            fontFamily: 'Arial', 
            fontSize: 24, 
            color: '#ffffff',
            align: 'center',
            stroke: '#000000',
            strokeThickness: 3
        }).setOrigin(0.5);
        
        // Implementação básica da trilha de notas
        this.highway = this.add.image(400, 300, 'highway')
            .setScale(1.2);
            
        // Botões de toque
        this.buttons = [];
        const buttonPositions = [250, 325, 400, 475, 550];
        
        buttonPositions.forEach((xPos, index) => {
            const button = this.add.image(xPos, 500, 'button')
                .setScale(0.8)
                .setInteractive()
                .setData('lane', index);
                
            button.on('pointerdown', () => {
                this.hitNote(index);
                button.setTint(0x00ff00);
            });
            
            button.on('pointerup', () => {
                button.clearTint();
            });
            
            button.on('pointerout', () => {
                button.clearTint();
            });
            
            this.buttons.push(button);
        });
        
        // Pontuação
        this.score = 0;
        this.scoreText = this.add.text(700, 50, 'Score: 0', { 
            fontFamily: 'Arial', 
            fontSize: 24, 
            color: '#ffffff'
        }).setOrigin(1, 0);
        
        // Multiplicador
        this.multiplier = 1;
        this.multiplierText = this.add.text(700, 90, 'x1', { 
            fontFamily: 'Arial', 
            fontSize: 24, 
            color: '#ffff00'
        }).setOrigin(1, 0);
        
        // Botão de pausa
        const pauseButton = this.add.rectangle(50, 50, 80, 40, 0x333333, 0.8)
            .setInteractive();
            
        const pauseText = this.add.text(50, 50, 'PAUSA', { 
            fontFamily: 'Arial', 
            fontSize: 16, 
            color: '#ffffff'
        }).setOrigin(0.5);
        
        pauseButton.on('pointerover', () => {
            pauseButton.setFillStyle(0x555555, 0.8);
        });
        
        pauseButton.on('pointerout', () => {
            pauseButton.setFillStyle(0x333333, 0.8);
        });
        
        pauseButton.on('pointerdown', () => {
            // Implementar menu de pausa
            this.scene.pause();
            // Aqui adicionaríamos um menu de pausa sobreposto
        });
        
        // Iniciar geração de notas (simulação básica)
        this.notes = this.physics.add.group();
        this.time.addEvent({
            delay: 1000,
            callback: this.spawnNote,
            callbackScope: this,
            loop: true
        });
    }
    
    spawnNote() {
        // Simulação básica de notas - em um jogo real, isso seria baseado no arquivo .chart
        const lane = Phaser.Math.Between(0, 4);
        const xPos = 250 + lane * 75;
        
        const note = this.notes.create(xPos, 0, 'note')
            .setScale(0.6)
            .setData('lane', lane);
            
        note.setVelocityY(300);
    }
    
    hitNote(lane) {
        let hit = false;
        
        this.notes.getChildren().forEach(note => {
            if (note.getData('lane') === lane && note.y > 450 && note.y < 550) {
                // Acerto!
                this.hitSound.play();
                note.destroy();
                
                // Aumentar pontuação
                this.score += 100 * this.multiplier;
                this.scoreText.setText(`Score: ${this.score}`);
                
                // Aumentar multiplicador
                this.multiplier = Math.min(4, this.multiplier + 0.1);
                this.multiplierText.setText(`x${this.multiplier.toFixed(1)}`);
                
                hit = true;
            }
        });
        
        if (!hit) {
            // Erro - nota não encontrada
            this.missSound.play();
            
            // Resetar multiplicador
            this.multiplier = 1;
            this.multiplierText.setText(`x${this.multiplier.toFixed(1)}`);
        }
    }
    
    update() {
        // Animação de fundo em movimento
        this.background.tilePositionY += 3;
        
        // Verificar notas perdidas
        this.notes.getChildren().forEach(note => {
            if (note.y > 550) {
                // Nota perdida
                this.missSound.play();
                note.destroy();
                
                // Resetar multiplicador
                this.multiplier = 1;
                this.multiplierText.setText(`x${this.multiplier.toFixed(1)}`);
            }
        });
    }
}
