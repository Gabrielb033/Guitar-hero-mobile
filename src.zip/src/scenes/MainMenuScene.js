class MainMenuScene extends Phaser.Scene {
    constructor() {
        super({ key: 'MainMenuScene' });
    }

    preload() {
        // Carregando recursos para o menu principal estilo Guitar Hero 3
        this.load.image('background', 'images/menu_background.jpg');
        this.load.image('logo', 'images/logo.png');
        this.load.image('menu_item', 'images/menu_item.png');
        this.load.image('particle', 'images/particle.png');
        
        // Efeitos sonoros
        this.load.audio('menu_music', 'audio/menu_music.mp3');
        this.load.audio('select_sound', 'audio/select.mp3');
        this.load.audio('hover_sound', 'audio/hover.mp3');
    }

    create() {
        // Música de fundo
        this.menuMusic = this.sound.add('menu_music', { loop: true, volume: 0.7 });
        this.menuMusic.play();
        
        // Sons de efeito
        this.hoverSound = this.sound.add('hover_sound', { volume: 0.5 });
        this.selectSound = this.sound.add('select_sound', { volume: 0.5 });
        
        // Background com efeito de paralaxe
        this.background = this.add.tileSprite(0, 0, 800, 600, 'background')
            .setOrigin(0)
            .setScrollFactor(0);
            
        // Sistema de partículas para animação de fundo
        this.particles = this.add.particles('particle');
        
        this.emitter = this.particles.createEmitter({
            x: 400,
            y: 300,
            speed: { min: 50, max: 150 },
            angle: { min: 0, max: 360 },
            scale: { start: 0.6, end: 0 },
            blendMode: 'ADD',
            lifespan: 2000,
            gravityY: 0,
            frequency: 100
        });
        
        // Logo do jogo
        this.logo = this.add.image(400, 120, 'logo')
            .setScale(0.8);
            
        // Efeito de brilho no logo
        this.tweens.add({
            targets: this.logo,
            alpha: 0.8,
            duration: 1500,
            ease: 'Sine.easeInOut',
            yoyo: true,
            repeat: -1
        });
        
        // Opções do menu estilo Guitar Hero 3
        const menuItems = [
            { text: 'JOGAR', scene: 'SongSelectScene' },
            { text: 'OPÇÕES', scene: null },
            { text: 'CRÉDITOS', scene: null },
            { text: 'SAIR', scene: null }
        ];
        
        this.menuOptions = [];
        
        menuItems.forEach((item, index) => {
            const y = 250 + index * 70;
            
            // Container para cada item do menu
            const container = this.add.container(400, y);
            
            // Fundo do item do menu
            const bg = this.add.image(0, 0, 'menu_item')
                .setAlpha(0.7)
                .setScale(1.2, 1);
                
            // Texto do item do menu
            const text = this.add.text(0, 0, item.text, { 
                fontFamily: 'Arial', 
                fontSize: 28, 
                color: '#ffffff',
                align: 'center'
            }).setOrigin(0.5);
            
            container.add([bg, text]);
            
            // Interatividade
            container.setSize(bg.width * 1.2, bg.height);
            container.setInteractive();
            
            container.on('pointerover', () => {
                this.hoverSound.play();
                bg.setAlpha(1);
                text.setScale(1.1);
                
                // Efeito de partículas ao passar o mouse
                this.emitter.setPosition(400, y);
                this.emitter.setQuantity(5);
                this.emitter.explode(10);
            });
            
            container.on('pointerout', () => {
                bg.setAlpha(0.7);
                text.setScale(1);
            });
            
            container.on('pointerdown', () => {
                this.selectSound.play();
                
                // Efeito de clique
                this.tweens.add({
                    targets: container,
                    scaleX: 0.9,
                    scaleY: 0.9,
                    duration: 100,
                    yoyo: true,
                    onComplete: () => {
                        if (item.scene) {
                            this.menuMusic.stop();
                            this.scene.start(item.scene);
                        }
                    }
                });
            });
            
            // Animação de entrada
            container.setAlpha(0);
            container.x = 900;
            
            this.tweens.add({
                targets: container,
                x: 400,
                alpha: 1,
                duration: 500,
                ease: 'Back.easeOut',
                delay: 200 + index * 100
            });
            
            this.menuOptions.push(container);
        });
    }
    
    update() {
        // Animação de fundo em movimento
        this.background.tilePositionX += 0.2;
        
        // Efeito de flutuação nos itens do menu
        this.menuOptions.forEach((item, index) => {
            item.y = 250 + index * 70 + Math.sin(this.time.now / 500 + index) * 5;
        });
    }
}
