class SongSelectScene extends Phaser.Scene {
    constructor() {
        super({ key: 'SongSelectScene' });
        this.selectedSongIndex = 0;
    }

    preload() {
        // Carregando recursos para o menu de seleção de músicas
        this.load.image('song_bg', 'images/song_select_bg.jpg');
        this.load.image('album_frame', 'images/album_frame.png');
        this.load.image('difficulty_star', 'images/difficulty_star.png');
        
        // Efeitos sonoros
        this.load.audio('scroll_sound', 'audio/scroll.mp3');
        this.load.audio('select_song_sound', 'audio/select_song.mp3');
        
        // Exemplos de capas de álbuns para demonstração
        this.load.image('album1', 'images/album1.jpg');
        this.load.image('album2', 'images/album2.jpg');
        this.load.image('album3', 'images/album3.jpg');
    }

    create() {
        // Background
        this.background = this.add.tileSprite(0, 0, 800, 600, 'song_bg')
            .setOrigin(0)
            .setScrollFactor(0);
            
        // Sons de efeito
        this.scrollSound = this.sound.add('scroll_sound', { volume: 0.5 });
        this.selectSongSound = this.sound.add('select_song_sound', { volume: 0.5 });
        
        // Título da tela
        this.add.text(400, 60, 'SELECIONAR MÚSICA', { 
            fontFamily: 'Arial', 
            fontSize: 36, 
            color: '#ffffff',
            align: 'center',
            stroke: '#000000',
            strokeThickness: 4
        }).setOrigin(0.5);
        
        // Dados de exemplo para as músicas
        this.songs = [
            { 
                title: 'Through the Fire and Flames', 
                artist: 'DragonForce', 
                album: 'album1',
                difficulty: 5,
                length: '7:21',
                year: 2006
            },
            { 
                title: 'Knights of Cydonia', 
                artist: 'Muse', 
                album: 'album2',
                difficulty: 4,
                length: '6:07',
                year: 2006
            },
            { 
                title: 'Cliffs of Dover', 
                artist: 'Eric Johnson', 
                album: 'album3',
                difficulty: 4,
                length: '4:09',
                year: 1990
            }
        ];
        
        // Criar carrossel de capas de álbuns
        this.albumCovers = [];
        this.albumFrames = [];
        this.songInfoTexts = [];
        
        // Container principal para o carrossel
        this.carousel = this.add.container(400, 300);
        
        // Criar elementos para cada música
        this.songs.forEach((song, index) => {
            // Posição inicial fora da tela
            const xPos = (index - this.selectedSongIndex) * 250;
            
            // Container para cada álbum
            const container = this.add.container(xPos, 0);
            
            // Capa do álbum
            const albumCover = this.add.image(0, 0, song.album)
                .setScale(0.8);
                
            // Moldura do álbum
            const albumFrame = this.add.image(0, 0, 'album_frame')
                .setScale(0.85);
                
            container.add([albumCover, albumFrame]);
            
            // Informações da música
            const songInfo = this.add.text(0, 180, `${song.title}\n${song.artist}`, { 
                fontFamily: 'Arial', 
                fontSize: 20, 
                color: '#ffffff',
                align: 'center',
                stroke: '#000000',
                strokeThickness: 3
            }).setOrigin(0.5);
            
            // Estrelas de dificuldade
            const difficultyContainer = this.add.container(0, 230);
            
            for (let i = 0; i < 5; i++) {
                const star = this.add.image((i - 2) * 25, 0, 'difficulty_star')
                    .setScale(0.5);
                    
                // Estrelas preenchidas até o nível de dificuldade
                if (i >= song.difficulty) {
                    star.setAlpha(0.3);
                }
                
                difficultyContainer.add(star);
            }
            
            container.add([songInfo, difficultyContainer]);
            
            // Escala inicial baseada na posição
            const scale = index === this.selectedSongIndex ? 1 : 0.7;
            container.setScale(scale);
            
            // Adicionar ao carrossel
            this.carousel.add(container);
            this.albumCovers.push(container);
        });
        
        // Botões de navegação
        const leftButton = this.add.triangle(150, 300, 0, 0, 0, 60, 40, 30, 0xffffff)
            .setAlpha(0.7)
            .setInteractive();
            
        const rightButton = this.add.triangle(650, 300, 0, 0, 0, 60, -40, 30, 0xffffff)
            .setAlpha(0.7)
            .setInteractive();
            
        leftButton.on('pointerover', () => leftButton.setAlpha(1));
        leftButton.on('pointerout', () => leftButton.setAlpha(0.7));
        rightButton.on('pointerover', () => rightButton.setAlpha(1));
        rightButton.on('pointerout', () => rightButton.setAlpha(0.7));
        
        leftButton.on('pointerdown', () => this.changeSong(-1));
        rightButton.on('pointerdown', () => this.changeSong(1));
        
        // Botão de seleção
        const selectButton = this.add.rectangle(400, 500, 200, 60, 0x333333, 0.8)
            .setInteractive();
            
        const selectText = this.add.text(400, 500, 'JOGAR', { 
            fontFamily: 'Arial', 
            fontSize: 24, 
            color: '#ffffff'
        }).setOrigin(0.5);
        
        selectButton.on('pointerover', () => {
            selectButton.setFillStyle(0x555555, 0.8);
            selectText.setScale(1.1);
        });
        
        selectButton.on('pointerout', () => {
            selectButton.setFillStyle(0x333333, 0.8);
            selectText.setScale(1);
        });
        
        selectButton.on('pointerdown', () => {
            this.selectSongSound.play();
            
            // Efeito de clique
            this.tweens.add({
                targets: [selectButton, selectText],
                scaleX: 0.9,
                scaleY: 0.9,
                duration: 100,
                yoyo: true,
                onComplete: () => {
                    // Iniciar o jogo com a música selecionada
                    this.scene.start('GameScene', { 
                        songIndex: this.selectedSongIndex,
                        songData: this.songs[this.selectedSongIndex]
                    });
                }
            });
        });
        
        // Botão de voltar
        const backButton = this.add.rectangle(100, 550, 150, 50, 0x333333, 0.8)
            .setInteractive();
            
        const backText = this.add.text(100, 550, 'VOLTAR', { 
            fontFamily: 'Arial', 
            fontSize: 20, 
            color: '#ffffff'
        }).setOrigin(0.5);
        
        backButton.on('pointerover', () => {
            backButton.setFillStyle(0x555555, 0.8);
            backText.setScale(1.1);
        });
        
        backButton.on('pointerout', () => {
            backButton.setFillStyle(0x333333, 0.8);
            backText.setScale(1);
        });
        
        backButton.on('pointerdown', () => {
            this.scrollSound.play();
            
            // Efeito de clique
            this.tweens.add({
                targets: [backButton, backText],
                scaleX: 0.9,
                scaleY: 0.9,
                duration: 100,
                yoyo: true,
                onComplete: () => {
                    this.scene.start('MainMenuScene');
                }
            });
        });
        
        // Detalhes da música selecionada
        this.songDetails = this.add.text(400, 400, this.getSongDetailsText(), { 
            fontFamily: 'Arial', 
            fontSize: 18, 
            color: '#ffffff',
            align: 'center'
        }).setOrigin(0.5);
        
        // Adicionar suporte a swipe para dispositivos móveis
        this.input.on('pointerdown', this.startSwipe, this);
        this.input.on('pointerup', this.endSwipe, this);
        this.input.on('pointerupoutside', this.endSwipe, this);
    }
    
    startSwipe(pointer) {
        this.swipeStartX = pointer.x;
    }
    
    endSwipe(pointer) {
        const swipeThreshold = 50;
        const swipeDistance = pointer.x - this.swipeStartX;
        
        if (Math.abs(swipeDistance) > swipeThreshold) {
            if (swipeDistance > 0) {
                this.changeSong(-1); // Swipe para direita
            } else {
                this.changeSong(1);  // Swipe para esquerda
            }
        }
    }
    
    changeSong(direction) {
        // Limitar a navegação ao número de músicas disponíveis
        const newIndex = Phaser.Math.Clamp(
            this.selectedSongIndex + direction, 
            0, 
            this.songs.length - 1
        );
        
        if (newIndex !== this.selectedSongIndex) {
            this.scrollSound.play();
            this.selectedSongIndex = newIndex;
            
            // Animar o carrossel
            this.albumCovers.forEach((container, index) => {
                const xPos = (index - this.selectedSongIndex) * 250;
                const scale = index === this.selectedSongIndex ? 1 : 0.7;
                const alpha = Math.abs(index - this.selectedSongIndex) <= 1 ? 1 : 0.5;
                
                this.tweens.add({
                    targets: container,
                    x: xPos,
                    scale: scale,
                    alpha: alpha,
                    duration: 300,
                    ease: 'Cubic.easeOut'
                });
            });
            
            // Atualizar detalhes da música
            this.songDetails.setText(this.getSongDetailsText());
        }
    }
    
    getSongDetailsText() {
        const song = this.songs[this.selectedSongIndex];
        return `Duração: ${song.length}  |  Ano: ${song.year}\nDificuldade: ${'★'.repeat(song.difficulty)}${'☆'.repeat(5 - song.difficulty)}`;
    }
    
    update() {
        // Animação de fundo em movimento
        this.background.tilePositionX += 0.1;
        this.background.tilePositionY += 0.05;
        
        // Efeito de flutuação no carrossel
        this.albumCovers.forEach((container, index) => {
            if (index === this.selectedSongIndex) {
                container.y = Math.sin(this.time.now / 1000) * 5;
            }
        });
    }
}
