// Configuração principal do jogo
const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    parent: 'game-container',
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },
    scene: [
        BootScene,
        MainMenuScene,
        SongSelectScene,
        GameScene
    ]
};

// Inicialização do jogo
window.onload = function() {
    const game = new Phaser.Game(config);
    
    // Adiciona o jogo à janela para acesso global
    window.game = game;
    
    // Ajusta o tamanho do jogo quando a janela é redimensionada
    window.addEventListener('resize', function() {
        game.scale.refresh();
    });
};
