// Integração do parser de charts com a interface do jogo
class GameChartIntegration {
    constructor(scene) {
        this.scene = scene;
        this.chartParser = new ChartParser();
        this.iniParser = new IniParser();
        this.songLoader = new CustomSongLoader(scene.game);
        this.currentSong = null;
        this.activeNotes = [];
        this.noteSprites = [];
        this.score = 0;
        this.multiplier = 1;
        this.combo = 0;
        this.isPlaying = false;
        this.startTime = 0;
    }

    /**
     * Carrega uma música de exemplo para demonstração
     */
    loadDemoSong() {
        // Criar dados de exemplo para demonstração
        const demoChartData = this.createDemoChartData();
        const demoIniData = this.createDemoIniData();
        
        // Simular carregamento de música
        this.currentSong = {
            chart: this.chartParser.parseChart(demoChartData),
            metadata: this.iniParser.parseIni(demoIniData),
            audio: this.scene.sound.add('demo_music'),
            albumArt: 'album1'
        };
        
        // Preparar notas para o jogo
        this.prepareNotes();
        
        return this.currentSong;
    }
    
    /**
     * Cria dados de chart de exemplo para demonstração
     */
    createDemoChartData() {
        return `
[Song]
{
  Name = "Demo Song"
  Artist = "Demo Artist"
  Charter = "Demo Charter"
  Resolution = 192
}

[SyncTrack]
{
  0 = B 120000
}

[ExpertSingle]
{
  768 = N 0 0
  960 = N 1 0
  1152 = N 2 0
  1344 = N 3 0
  1536 = N 4 0
  1728 = N 0 0
  1920 = N 1 0
  2112 = N 2 0
  2304 = N 3 0
  2496 = N 4 0
  2688 = N 0 0
  2880 = N 1 0
  3072 = N 2 0
  3264 = N 3 0
  3456 = N 4 0
  3648 = N 0 0
  3840 = N 1 0
  4032 = N 2 0
  4224 = N 3 0
  4416 = N 4 0
}`;
    }
    
    /**
     * Cria dados de ini de exemplo para demonstração
     */
    createDemoIniData() {
        return `
[Song]
name = Demo Song
artist = Demo Artist
album = Demo Album
year = 2025
charter = Demo Charter
difficulty = 4
`;
    }
    
    /**
     * Prepara as notas para o jogo
     */
    prepareNotes() {
        if (!this.currentSong) return;
        
        // Limpar notas anteriores
        this.activeNotes = [];
        
        // Converter notas do chart para o formato do jogo
        this.currentSong.chart.notes.forEach(note => {
            this.activeNotes.push({
                time: note.time,
                lane: note.lane,
                duration: note.duration,
                spawned: false,
                hit: false,
                missed: false,
                sprite: null
            });
        });
    }
    
    /**
     * Inicia a reprodução da música
     */
    startSong() {
        if (!this.currentSong || this.isPlaying) return;
        
        this.isPlaying = true;
        this.startTime = this.scene.time.now;
        this.currentSong.audio.play();
        
        // Resetar pontuação
        this.score = 0;
        this.multiplier = 1;
        this.combo = 0;
        
        // Atualizar UI
        this.updateScoreDisplay();
        
        console.log('Música iniciada!');
    }
    
    /**
     * Pausa a reprodução da música
     */
    pauseSong() {
        if (!this.isPlaying) return;
        
        this.isPlaying = false;
        this.currentSong.audio.pause();
        
        console.log('Música pausada!');
    }
    
    /**
     * Atualiza o estado do jogo
     * @param {number} time - Tempo atual
     * @param {number} delta - Tempo desde a última atualização
     */
    update(time, delta) {
        if (!this.isPlaying) return;
        
        const currentTime = time - this.startTime;
        
        // Verificar notas para spawnar
        this.activeNotes.forEach(note => {
            // Calcular quando a nota deve aparecer (2 segundos antes do tempo de acerto)
            const spawnTime = note.time - 2000;
            
            // Spawnar notas que devem aparecer agora
            if (!note.spawned && currentTime >= spawnTime) {
                this.spawnNote(note);
                note.spawned = true;
            }
            
            // Atualizar posição das notas visíveis
            if (note.spawned && note.sprite && !note.hit && !note.missed) {
                this.updateNotePosition(note, currentTime);
            }
            
            // Verificar notas perdidas
            if (note.spawned && !note.hit && !note.missed && currentTime > note.time + 200) {
                this.missNote(note);
                note.missed = true;
            }
        });
    }
    
    /**
     * Cria uma nota no jogo
     * @param {Object} note - Dados da nota
     */
    spawnNote(note) {
        // Posição X baseada na pista (0-4)
        const lanePositions = [250, 325, 400, 475, 550];
        const x = lanePositions[note.lane];
        const y = 0; // Topo da tela
        
        // Criar sprite da nota
        note.sprite = this.scene.add.image(x, y, 'note');
        note.sprite.setScale(0.6);
        
        // Colorir a nota de acordo com a pista
        const colors = [0x00ff00, 0xff0000, 0xffff00, 0x0000ff, 0xff8800]; // Verde, Vermelho, Amarelo, Azul, Laranja
        note.sprite.setTint(colors[note.lane]);
        
        // Adicionar à lista de sprites
        this.noteSprites.push(note.sprite);
    }
    
    /**
     * Atualiza a posição de uma nota
     * @param {Object} note - Dados da nota
     * @param {number} currentTime - Tempo atual
     */
    updateNotePosition(note, currentTime) {
        if (!note.sprite) return;
        
        // Calcular progresso da nota (0 a 1)
        const spawnTime = note.time - 2000; // 2 segundos antes
        const hitTime = note.time;
        const progress = (currentTime - spawnTime) / (hitTime - spawnTime);
        
        // Calcular posição Y (de 0 a 500)
        const y = Math.min(500, progress * 500);
        
        // Atualizar posição do sprite
        note.sprite.y = y;
    }
    
    /**
     * Processa um acerto de nota
     * @param {number} lane - Pista da nota (0-4)
     * @returns {boolean} Se alguma nota foi acertada
     */
    hitNote(lane) {
        if (!this.isPlaying) return false;
        
        const currentTime = this.scene.time.now - this.startTime;
        let hitSuccess = false;
        
        // Encontrar a nota mais próxima na pista especificada
        const notesInLane = this.activeNotes.filter(
            note => note.lane === lane && note.spawned && !note.hit && !note.missed
        );
        
        if (notesInLane.length > 0) {
            // Ordenar por proximidade ao tempo de acerto
            notesInLane.sort((a, b) => 
                Math.abs(a.time - currentTime) - Math.abs(b.time - currentTime)
            );
            
            const closestNote = notesInLane[0];
            
            // Verificar se está dentro da janela de acerto (200ms)
            if (Math.abs(closestNote.time - currentTime) <= 200) {
                this.processHit(closestNote);
                hitSuccess = true;
            }
        }
        
        return hitSuccess;
    }
    
    /**
     * Processa um acerto de nota
     * @param {Object} note - Dados da nota
     */
    processHit(note) {
        note.hit = true;
        
        // Remover sprite
        if (note.sprite) {
            // Efeito de desaparecimento
            this.scene.tweens.add({
                targets: note.sprite,
                alpha: 0,
                scale: 1.2,
                duration: 100,
                onComplete: () => {
                    note.sprite.destroy();
                    
                    // Remover da lista de sprites
                    const index = this.noteSprites.indexOf(note.sprite);
                    if (index !== -1) {
                        this.noteSprites.splice(index, 1);
                    }
                    
                    note.sprite = null;
                }
            });
        }
        
        // Reproduzir som de acerto
        this.scene.sound.play('hit_sound');
        
        // Aumentar combo
        this.combo++;
        
        // Aumentar multiplicador a cada 10 combos
        if (this.combo % 10 === 0) {
            this.multiplier = Math.min(4, this.multiplier + 1);
        }
        
        // Adicionar pontuação
        this.score += 100 * this.multiplier;
        
        // Atualizar UI
        this.updateScoreDisplay();
        
        // Efeito visual de acerto
        this.createHitEffect(note.lane);
    }
    
    /**
     * Processa uma nota perdida
     * @param {Object} note - Dados da nota
     */
    missNote(note) {
        note.missed = true;
        
        // Remover sprite
        if (note.sprite) {
            // Efeito de desaparecimento
            this.scene.tweens.add({
                targets: note.sprite,
                alpha: 0,
                duration: 100,
                onComplete: () => {
                    note.sprite.destroy();
                    
                    // Remover da lista de sprites
                    const index = this.noteSprites.indexOf(note.sprite);
                    if (index !== -1) {
                        this.noteSprites.splice(index, 1);
                    }
                    
                    note.sprite = null;
                }
            });
        }
        
        // Reproduzir som de erro
        this.scene.sound.play('miss_sound');
        
        // Resetar combo
        this.combo = 0;
        
        // Resetar multiplicador
        this.multiplier = 1;
        
        // Atualizar UI
        this.updateScoreDisplay();
    }
    
    /**
     * Cria um efeito visual de acerto
     * @param {number} lane - Pista do acerto (0-4)
     */
    createHitEffect(lane) {
        // Posição X baseada na pista (0-4)
        const lanePositions = [250, 325, 400, 475, 550];
        const x = lanePositions[lane];
        const y = 500; // Posição dos botões
        
        // Criar partículas
        const particles = this.scene.add.particles('particle');
        
        const emitter = particles.createEmitter({
            x: x,
            y: y,
            speed: { min: 50, max: 150 },
            angle: { min: -30, max: 30 },
            scale: { start: 0.5, end: 0 },
            blendMode: 'ADD',
            lifespan: 500,
            gravityY: 300
        });
        
        // Emitir partículas
        emitter.explode(10);
        
        // Destruir sistema de partículas após 1 segundo
        this.scene.time.delayedCall(1000, () => {
            particles.destroy();
        });
    }
    
    /**
     * Atualiza a exibição de pontuação
     */
    updateScoreDisplay() {
        // Atualizar texto de pontuação
        if (this.scene.scoreText) {
            this.scene.scoreText.setText(`Score: ${this.score}`);
        }
        
        // Atualizar texto de multiplicador
        if (this.scene.multiplierText) {
            this.scene.multiplierText.setText(`x${this.multiplier}`);
        }
    }
    
    /**
     * Limpa recursos ao finalizar
     */
    cleanup() {
        // Parar música
        if (this.currentSong && this.currentSong.audio) {
            this.currentSong.audio.stop();
        }
        
        // Destruir sprites de notas
        this.noteSprites.forEach(sprite => {
            if (sprite) sprite.destroy();
        });
        
        this.noteSprites = [];
        this.activeNotes = [];
        this.isPlaying = false;
    }
}

// Atualização da cena de jogo para integrar o parser
class GameSceneWithChart extends Phaser.Scene {
    constructor() {
        super({ key: 'GameSceneWithChart' });
    }

    init(data) {
        this.songIndex = data.songIndex;
        this.songData = data.songData;
    }

    preload() {
        // Carregar recursos para o jogo
        this.load.image('game_bg', 'images/game_bg.jpg');
        this.load.image('note', 'images/note.png');
        this.load.image('highway', 'images/highway.png');
        this.load.image('button', 'images/button.png');
        this.load.image('particle', 'images/particle.png');
        
        // Efeitos sonoros
        this.load.audio('hit_sound', 'audio/hit.mp3');
        this.load.audio('miss_sound', 'audio/miss.mp3');
        
        // Música de demonstração
        this.load.audio('demo_music', 'audio/demo_music.mp3');
        
        // Imagens de álbum de demonstração
        this.load.image('album1', 'images/album1.jpg');
    }

    create() {
        // Background
        this.background = this.add.tileSprite(0, 0, 800, 600, 'game_bg')
            .setOrigin(0)
            .setScrollFactor(0);
            
        // Trilha de notas
        this.highway = this.add.image(400, 300, 'highway')
            .setScale(1.2);
            
        // Botões de toque
        this.buttons = [];
        const buttonPositions = [250, 325, 400, 475, 550];
        
        buttonPositions.forEach((xPos, index) => {
            const button = this.add.image(xPos, 500, 'button')
                .setScale(0.8)
                .setInteractive()
                .setData('lane', index);
                
            // Colorir botão de acordo com a pista
            const colors = [0x00ff00, 0xff0000, 0xffff00, 0x0000ff, 0xff8800]; // Verde, Vermelho, Amarelo, Azul, Laranja
            button.setTint(colors[index]);
                
            button.on('pointerdown', () => {
                this.chartIntegration.hitNote(index);
                button.setScale(0.7);
            });
            
            button.on('pointerup', () => {
                button.setScale(0.8);
            });
            
            button.on('pointerout', () => {
                button.setScale(0.8);
            });
            
            this.buttons.push(button);
        });
        
        // Informações da música
        this.add.text(400, 30, "Demo Song - Demo Artist", { 
            fontFamily: 'Arial', 
            fontSize: 24, 
            color: '#ffffff',
            align: 'center',
            stroke: '#000000',
            strokeThickness: 3
        }).setOrigin(0.5);
        
        // Pontuação
        this.scoreText = this.add.text(700, 50, 'Score: 0', { 
            fontFamily: 'Arial', 
            fontSize: 24, 
            color: '#ffffff'
        }).setOrigin(1, 0);
        
        // Multiplicador
        this.multiplierText = this.add.text(700, 90, 'x1', { 
            fontFamily: 'Arial', 
            fontSize: 24, 
            color: '#ffff00'
        }).setOrigin(1, 0);
        
        // Botão de pausa
        const pauseButton = this.add.rectangle(50, 50, 80, 40, 0x333333, 0.8)
            .setInteractive();
            
        const pauseText = this.add.text(50, 50, 'PAUSA', { 
            fontFamily: 'Arial', 
            fontSize: 16, 
            color: '#ffffff'
        }).setOrigin(0.5);
        
        pauseButton.on('pointerover', () => {
            pauseButton.setFillStyle(0x555555, 0.8);
        });
        
        pauseButton.on('pointerout', () => {
            pauseButton.setFillStyle(0x333333, 0.8);
        });
        
        pauseButton.on('pointerdown', () => {
            if (this.chartIntegration.isPlaying) {
                this.chartIntegration.pauseSong();
                pauseText.setText('TOCAR');
            } else {
                this.chartIntegration.startSong();
                pauseText.setText('PAUSA');
            }
        });
        
        // Inicializar integração com o parser de charts
        this.chartIntegration = new GameChartIntegration(this);
        
        // Carregar música de demonstração
        this.chartIntegration.loadDemoSong();
        
        // Botão de iniciar
        const startButton = this.add.rectangle(400, 300, 200, 60, 0x333333, 0.8)
            .setInteractive();
            
        const startText = this.add.text(400, 300, 'INICIAR DEMO', { 
            fontFamily: 'Arial', 
            fontSize: 24, 
            color: '#ffffff'
        }).setOrigin(0.5);
        
        startButton.on('pointerover', () => {
            startButton.setFillStyle(0x555555, 0.8);
            startText.setScale(1.1);
        });
        
        startButton.on('pointerout', () => {
            startButton.setFillStyle(0x333333, 0.8);
            startText.setScale(1);
        });
        
        startButton.on('pointerdown', () => {
            // Efeito de clique
            this.tweens.add({
                targets: [startButton, startText],
                scaleX: 0.9,
                scaleY: 0.9,
                duration: 100,
                yoyo: true,
                onComplete: () => {
                    // Esconder botão de iniciar
                    startButton.setVisible(false);
                    startText.setVisible(false);
                    
                    // Iniciar música
                    this.chartIntegration.startSong();
                }
            });
        });
    }
    
    update(time, delta) {
        // Animação de fundo em movimento
        this.background.tilePositionY += 1;
        
        // Atualizar integração com o parser de charts
        if (this.chartIntegration) {
            this.chartIntegration.update(time, delta);
        }
    }
}
