package com.manus.guitarhero;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
