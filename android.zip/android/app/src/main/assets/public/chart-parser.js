// Implementação do parser de arquivos .chart do Clone Hero
class ChartParser {
    constructor() {
        this.notes = [];
        this.songInfo = {};
        this.resolution = 192; // Resolução padrão (ticks por beat)
        this.bpm = 120; // BPM padrão
    }

    /**
     * Analisa o conteúdo de um arquivo .chart
     * @param {string} chartContent - Conteúdo do arquivo .chart
     * @returns {Object} Dados processados do chart
     */
    parseChart(chartContent) {
        // Limpar dados anteriores
        this.notes = [];
        this.songInfo = {};
        
        // Dividir o conteúdo em seções
        const sections = this.extractSections(chartContent);
        
        // Processar seção de informações da música
        if (sections.Song) {
            this.parseSongSection(sections.Song);
        }
        
        // Processar seção de sincronização
        if (sections.SyncTrack) {
            this.parseSyncTrack(sections.SyncTrack);
        }
        
        // Processar seção de notas (Expert Single)
        if (sections['ExpertSingle']) {
            this.parseNotesSection(sections['ExpertSingle']);
        }
        
        return {
            notes: this.notes,
            songInfo: this.songInfo,
            resolution: this.resolution,
            bpm: this.bpm
        };
    }
    
    /**
     * Extrai as seções do arquivo .chart
     * @param {string} content - Conteúdo do arquivo
     * @returns {Object} Seções extraídas
     */
    extractSections(content) {
        const sections = {};
        const sectionRegex = /\[([^\]]+)\]\s*{([^}]*)}/g;
        let match;
        
        while ((match = sectionRegex.exec(content)) !== null) {
            const sectionName = match[1].trim();
            const sectionContent = match[2].trim();
            sections[sectionName] = sectionContent;
        }
        
        return sections;
    }
    
    /**
     * Processa a seção de informações da música
     * @param {string} sectionContent - Conteúdo da seção
     */
    parseSongSection(sectionContent) {
        const nameRegex = /Name\s*=\s*"([^"]*)"/;
        const artistRegex = /Artist\s*=\s*"([^"]*)"/;
        const charterRegex = /Charter\s*=\s*"([^"]*)"/;
        const resolutionRegex = /Resolution\s*=\s*(\d+)/;
        
        const nameMatch = sectionContent.match(nameRegex);
        const artistMatch = sectionContent.match(artistRegex);
        const charterMatch = sectionContent.match(charterRegex);
        const resolutionMatch = sectionContent.match(resolutionRegex);
        
        if (nameMatch) this.songInfo.name = nameMatch[1];
        if (artistMatch) this.songInfo.artist = artistMatch[1];
        if (charterMatch) this.songInfo.charter = charterMatch[1];
        if (resolutionMatch) this.resolution = parseInt(resolutionMatch[1]);
    }
    
    /**
     * Processa a seção de sincronização
     * @param {string} sectionContent - Conteúdo da seção
     */
    parseSyncTrack(sectionContent) {
        const bpmRegex = /\s*(\d+)\s*=\s*B\s*(\d+)/g;
        let match;
        
        while ((match = bpmRegex.exec(sectionContent)) !== null) {
            const position = parseInt(match[1]);
            // BPM é armazenado como inteiro multiplicado por 1000
            const bpmValue = parseInt(match[2]) / 1000;
            
            if (position === 0) {
                this.bpm = bpmValue;
            }
            
            // Aqui poderíamos armazenar mudanças de BPM ao longo da música
        }
    }
    
    /**
     * Processa a seção de notas
     * @param {string} sectionContent - Conteúdo da seção
     */
    parseNotesSection(sectionContent) {
        const noteRegex = /\s*(\d+)\s*=\s*N\s*(\d+)\s*(\d+)/g;
        let match;
        
        while ((match = noteRegex.exec(sectionContent)) !== null) {
            const position = parseInt(match[1]);
            const fret = parseInt(match[2]);
            const duration = parseInt(match[3]);
            
            // Converter posição em ticks para tempo em milissegundos
            const timeMs = this.ticksToMs(position);
            const durationMs = this.ticksToMs(duration);
            
            // Adicionar nota à lista
            this.notes.push({
                time: timeMs,
                lane: fret, // 0-4 para as cinco pistas
                duration: durationMs,
                position: position // Manter a posição original em ticks
            });
        }
        
        // Ordenar notas por tempo
        this.notes.sort((a, b) => a.time - b.time);
    }
    
    /**
     * Converte ticks para milissegundos
     * @param {number} ticks - Número de ticks
     * @returns {number} Tempo em milissegundos
     */
    ticksToMs(ticks) {
        // Fórmula: (ticks / resolution) * (60000 / bpm)
        return (ticks / this.resolution) * (60000 / this.bpm);
    }
}

// Implementação do leitor de arquivos .ini
class IniParser {
    /**
     * Analisa o conteúdo de um arquivo .ini
     * @param {string} iniContent - Conteúdo do arquivo .ini
     * @returns {Object} Dados processados do arquivo .ini
     */
    parseIni(iniContent) {
        const result = {};
        let currentSection = '';
        
        // Dividir o conteúdo em linhas
        const lines = iniContent.split('\n');
        
        for (const line of lines) {
            const trimmedLine = line.trim();
            
            // Ignorar linhas vazias e comentários
            if (trimmedLine === '' || trimmedLine.startsWith(';')) {
                continue;
            }
            
            // Verificar se é uma seção
            const sectionMatch = trimmedLine.match(/^\[([^\]]+)\]$/);
            if (sectionMatch) {
                currentSection = sectionMatch[1];
                result[currentSection] = {};
                continue;
            }
            
            // Verificar se é um par chave-valor
            const keyValueMatch = trimmedLine.match(/^([^=]+)=(.*)$/);
            if (keyValueMatch && currentSection) {
                const key = keyValueMatch[1].trim();
                const value = keyValueMatch[2].trim();
                result[currentSection][key] = value;
            }
        }
        
        return result;
    }
}

// Sistema de carregamento de músicas personalizadas
class CustomSongLoader {
    constructor(game) {
        this.game = game;
        this.chartParser = new ChartParser();
        this.iniParser = new IniParser();
        this.songs = [];
    }
    
    /**
     * Carrega uma música personalizada
     * @param {Object} songData - Dados da música (caminhos para arquivos)
     * @returns {Promise} Promessa que resolve quando a música é carregada
     */
    async loadSong(songData) {
        try {
            // Carregar arquivo .chart
            const chartContent = await this.loadTextFile(songData.chartPath);
            const chartData = this.chartParser.parseChart(chartContent);
            
            // Carregar arquivo .ini
            const iniContent = await this.loadTextFile(songData.iniPath);
            const iniData = this.iniParser.parseIni(iniContent);
            
            // Carregar áudio
            const audio = await this.loadAudio(songData.audioPath);
            
            // Carregar imagem de capa
            const albumArt = await this.loadImage(songData.imagePath);
            
            // Combinar todos os dados
            const song = {
                id: this.songs.length,
                chart: chartData,
                metadata: iniData,
                audio: audio,
                albumArt: albumArt,
                path: songData
            };
            
            this.songs.push(song);
            return song;
        } catch (error) {
            console.error('Erro ao carregar música:', error);
            throw error;
        }
    }
    
    /**
     * Carrega um arquivo de texto
     * @param {string} path - Caminho do arquivo
     * @returns {Promise<string>} Conteúdo do arquivo
     */
    loadTextFile(path) {
        return new Promise((resolve, reject) => {
            fetch(path)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Erro ao carregar arquivo: ${response.status}`);
                    }
                    return response.text();
                })
                .then(content => resolve(content))
                .catch(error => reject(error));
        });
    }
    
    /**
     * Carrega um arquivo de áudio
     * @param {string} path - Caminho do arquivo
     * @returns {Promise<HTMLAudioElement>} Elemento de áudio
     */
    loadAudio(path) {
        return new Promise((resolve, reject) => {
            const audio = new Audio();
            audio.src = path;
            
            audio.oncanplaythrough = () => {
                resolve(audio);
            };
            
            audio.onerror = () => {
                reject(new Error('Erro ao carregar áudio'));
            };
            
            audio.load();
        });
    }
    
    /**
     * Carrega uma imagem
     * @param {string} path - Caminho do arquivo
     * @returns {Promise<HTMLImageElement>} Elemento de imagem
     */
    loadImage(path) {
        return new Promise((resolve, reject) => {
            const image = new Image();
            image.src = path;
            
            image.onload = () => {
                resolve(image);
            };
            
            image.onerror = () => {
                reject(new Error('Erro ao carregar imagem'));
            };
        });
    }
    
    /**
     * Obtém todas as músicas carregadas
     * @returns {Array} Lista de músicas
     */
    getAllSongs() {
        return this.songs;
    }
    
    /**
     * Obtém uma música pelo ID
     * @param {number} id - ID da música
     * @returns {Object} Dados da música
     */
    getSongById(id) {
        return this.songs.find(song => song.id === id);
    }
}

// Integração com o jogo
class ChartGameIntegration {
    constructor(scene) {
        this.scene = scene;
        this.songLoader = new CustomSongLoader(scene.game);
        this.currentSong = null;
        this.isPlaying = false;
        this.startTime = 0;
        this.noteSpeed = 300; // Velocidade das notas em pixels por segundo
        this.noteSpawnPoint = 0;
        this.noteHitPoint = 500;
        this.visibleNotes = [];
    }
    
    /**
     * Carrega e prepara uma música para jogar
     * @param {Object} songData - Dados da música
     * @returns {Promise} Promessa que resolve quando a música está pronta
     */
    async loadSong(songData) {
        try {
            this.currentSong = await this.songLoader.loadSong(songData);
            this.prepareNotes();
            return this.currentSong;
        } catch (error) {
            console.error('Erro ao carregar música para o jogo:', error);
            throw error;
        }
    }
    
    /**
     * Prepara as notas para o jogo
     */
    prepareNotes() {
        if (!this.currentSong) return;
        
        // Converter notas do chart para o formato do jogo
        this.gameNotes = this.currentSong.chart.notes.map(note => ({
            time: note.time,
            lane: note.lane,
            duration: note.duration,
            spawned: false,
            hit: false,
            missed: false,
            sprite: null
        }));
    }
    
    /**
     * Inicia a reprodução da música
     */
    startSong() {
        if (!this.currentSong || this.isPlaying) return;
        
        this.isPlaying = true;
        this.startTime = Date.now();
        this.currentSong.audio.currentTime = 0;
        this.currentSong.audio.play();
        
        // Iniciar o loop de atualização
        this.scene.events.on('update', this.update, this);
    }
    
    /**
     * Pausa a reprodução da música
     */
    pauseSong() {
        if (!this.isPlaying) return;
        
        this.isPlaying = false;
        this.currentSong.audio.pause();
        
        // Parar o loop de atualização
        this.scene.events.off('update', this.update, this);
    }
    
    /**
     * Atualiza o estado do jogo
     * @param {number} time - Tempo atual
     * @param {number} delta - Tempo desde a última atualização
     */
    update(time, delta) {
        if (!this.isPlaying) return;
        
        const currentTime = Date.now() - this.startTime;
        
        // Verificar notas para spawnar
        this.gameNotes.forEach(note => {
            // Calcular quando a nota deve aparecer
            const spawnTime = note.time - this.calculateSpawnDelay();
            
            // Spawnar notas que devem aparecer agora
            if (!note.spawned && currentTime >= spawnTime) {
                this.spawnNote(note);
                note.spawned = true;
            }
            
            // Atualizar posição das notas visíveis
            if (note.spawned && note.sprite && !note.hit && !note.missed) {
                this.updateNotePosition(note, currentTime);
            }
            
            // Verificar notas perdidas
            if (note.spawned && !note.hit && !note.missed && currentTime > note.time + 200) {
                this.missNote(note);
                note.missed = true;
            }
        });
    }
    
    /**
     * Calcula o atraso de spawn baseado na velocidade das notas
     * @returns {number} Atraso em milissegundos
     */
    calculateSpawnDelay() {
        // Distância entre o ponto de spawn e o ponto de acerto
        const distance = this.noteHitPoint - this.noteSpawnPoint;
        
        // Tempo = distância / velocidade
        return (distance / this.noteSpeed) * 1000;
    }
    
    /**
     * Cria uma nota no jogo
     * @param {Object} note - Dados da nota
     */
    spawnNote(note) {
        // Criar sprite da nota
        const x = 250 + note.lane * 75; // Posição X baseada na pista
        const y = this.noteSpawnPoint;
        
        // Aqui usaríamos Phaser para criar o sprite
        // note.sprite = this.scene.add.sprite(x, y, 'note');
        
        // Adicionar à lista de notas visíveis
        this.visibleNotes.push(note);
    }
    
    /**
     * Atualiza a posição de uma nota
     * @param {Object} note - Dados da nota
     * @param {number} currentTime - Tempo atual
     */
    updateNotePosition(note, currentTime) {
        // Calcular progresso da nota (0 a 1)
        const totalDistance = this.noteHitPoint - this.noteSpawnPoint;
        const spawnTime = note.time - this.calculateSpawnDelay();
        const hitTime = note.time;
        const progress = (currentTime - spawnTime) / (hitTime - spawnTime);
        
        // Calcular posição Y
        const y = this.noteSpawnPoint + (totalDistance * progress);
        
        // Atualizar posição do sprite
        if (note.sprite) {
            // note.sprite.y = y;
        }
    }
    
    /**
     * Processa um acerto de nota
     * @param {number} lane - Pista da nota (0-4)
     * @returns {boolean} Se alguma nota foi acertada
     */
    hitNote(lane) {
        if (!this.isPlaying) return false;
        
        const currentTime = Date.now() - this.startTime;
        let hitSuccess = false;
        
        // Encontrar a nota mais próxima na pista especificada
        const notesInLane = this.visibleNotes.filter(
            note => note.lane === lane && !note.hit && !note.missed
        );
        
        if (notesInLane.length > 0) {
            // Ordenar por proximidade ao tempo de acerto
            notesInLane.sort((a, b) => 
                Math.abs(a.time - currentTime) - Math.abs(b.time - currentTime)
            );
            
            const closestNote = notesInLane[0];
            
            // Verificar se está dentro da janela de acerto
            if (Math.abs(closestNote.time - currentTime) <= 200) {
                this.processHit(closestNote);
                hitSuccess = true;
            }
        }
        
        return hitSuccess;
    }
    
    /**
     * Processa um acerto de nota
     * @param {Object} note - Dados da nota
     */
    processHit(note) {
        note.hit = true;
        
        // Remover da lista de notas visíveis
        const index = this.visibleNotes.indexOf(note);
        if (index !== -1) {
            this.visibleNotes.splice(index, 1);
        }
        
        // Remover sprite
        if (note.sprite) {
            // note.sprite.destroy();
            note.sprite = null;
        }
        
        // Aqui adicionaríamos efeitos visuais, som, pontuação, etc.
    }
    
    /**
     * Processa uma nota perdida
     * @param {Object} note - Dados da nota
     */
    missNote(note) {
        note.missed = true;
        
        // Remover da lista de notas visíveis
        const index = this.visibleNotes.indexOf(note);
        if (index !== -1) {
            this.visibleNotes.splice(index, 1);
        }
        
        // Remover sprite
        if (note.sprite) {
            // note.sprite.destroy();
            note.sprite = null;
        }
        
        // Aqui adicionaríamos efeitos visuais, som, redução de multiplicador, etc.
    }
}
